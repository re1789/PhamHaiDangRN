<html>
    <body style="align-items: center";>
        <form name="f-hello" action="xl_chao.php" method="POST" >
        <h1 style="color: #090" >HIỆN CÂU CHÀO</h1>
        Nhập họ tên: <input type="text" name="ten" id="ten" ><br>
        <input type="submit" value="Hiện Câu Chào" name="btOK" id="btOK">
        </form>
    </body>
</html>
