<?php
$danhSach = array(
    array(1, "Dương Vũ Ngọc", "Ân", "Nam", "ngocan@gmail.com"),
    array(2, "Trần Ngọc", "Đạt", "Nam", "ngocdat@yahoo.com"),
    array(3, "Đào Nguyễn Ngọc", "Linh", "Nữ", "ngoclinh@gmail.com"),
    array(4, "Phạm Hải", "Đăng", "Nam", "mmb@gmail.com")
);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Documren</title>
</head>

<body style="font-family: 'Times New Roman', Times, serif;">

    <div style="text-align: center; font-size: 24px; font-weight: bold; margin-bottom: 10px;">
        DANH SÁCH LỚP CT15CD31
    </div>

    <table style="width: 90%; margin: auto; border-collapse: collapse; font-size: 24px;">

        <tr>
            <th style="border: 1px solid black; padding: 10px;">STT</th>
            <th style="border: 1px solid black; padding: 10px;">Họ</th>
            <th style="border: 1px solid black; padding: 10px;">Tên</th>
            <th style="border: 1px solid black; padding: 10px;">Phái</th>
            <th style="border: 1px solid black; padding: 10px;">Email</th>
        </tr>

        <?php
        foreach ($danhSach as $nguoi) {
        ?>

        <tr>
            <td style="border: 1px solid black; padding: 10px; text-align: center;">
                <?php echo $nguoi[0]; ?>
            </td>

            <td style="border: 1px solid black; padding: 10px;">
                <?php echo $nguoi[1]; ?>
            </td>

            <td style="border: 1px solid black; padding: 10px;">
                <?php echo $nguoi[2]; ?>
            </td>

            <td style="border: 1px solid black; padding: 10px;">
                <?php echo $nguoi[3]; ?>
            </td>

            <td style="border: 1px solid black; padding: 10px;">
                <a href="mailto:<?php echo $nguoi[4]; ?>" style="color: black;">
                    <?php echo $nguoi[4]; ?>
                </a>
            </td>
        </tr>

        <?php
        }
        ?>

    </table>

</body>
</html>
