<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Nhập thông tin</title>

    <style>
        body {
            font-family: "Times New Roman", serif;
            font-size: 20px;
        }

        .khung {
            width: 870px;
            margin: 40px auto;
            border: 1px solid black;
            padding: 10px 0 25px 0;
        }

        h1 {
            text-align: center;
            color: blue;
            font-size: 50px;
            font-weight: normal;
            margin: 0 0 35px 0;
        }

        .form {
            width: 500px;
            margin: auto;
        }

        .dong {
            margin-bottom: 5px;
        }

        label {
            display: inline-block;
            width: 200px;
        }

        input[type="text"],
        input[type="number"],
        select {
            width: 305px;
            height: 34px;
            font-size: 18px;
            box-sizing: border-box;
        }

        .nut {
            margin-left: 205px;
            margin-top: 30px;
        }

        input[type="submit"],
        input[type="reset"] {
            font-size: 18px;
            padding: 5px 15px;
            margin-right: 8px;
        }
    </style>
</head>
    <body>
        <div class="khung">
            <h1>Bạn vui lòng nhập các thông tin sau</h1>
            <form class="form" action="xl_xuly.php" method="post">
                <div class="dong">
                    <label>Tên</label>
                    <input type="text" name="ten" required>
                </div>
                <div class="dong">
                    <label>Năm sinh</label>
                    <input type="number" name="namsinh" min="1900" max="2026" required>
                </div>
                <div class="dong">
                    <label>Sở thích</label>
                    <select name="sothich">
                        <option value="Thể thao">Thể thao</option>
                        <option value="Phim ảnh">Phim ảnh</option>
                        <option value="Tin tức">Tin tức</option>
                    </select>
                </div>
                <div class="nut">
                    <input type="submit" value="Gửi">
                    <input type="reset" value="Làm lại">
                </div>
            </form>
        </div>
    </body>
</html>