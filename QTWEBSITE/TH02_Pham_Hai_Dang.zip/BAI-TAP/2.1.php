<html>
	<body>
		<?php
			echo "Hello the world!"; //We will look at this later
		?>
	</body>
</html>
