<?php
if (isset($_POST['dangky'])) {
    $ho = $_POST['ho'];
    $ten = $_POST['ten'];
    $email = $_POST['email'];

    echo "<h3 style='text-align:center; color:green;'>Thông tin đã đăng ký:</h3>";
    echo "<p style='text-align:center;'>Chào bạn: $ho $ten</p>";
    echo "<p style='text-align:center;'>Email của bạn là: $email</p>";
}
?>