<?php
	$ho = 'Nguyen Dang';
	$ten = 'Khoa';
	$namsinh = 1978;
	$hoten = $ho . ' ' . $ten;
	echo $ho;
    echo' ';
	echo $ten;
	echo '<br />';
	echo 'Ho ten: ' . $hoten . 'Nam sinh: ' . $namsinh;
?>
