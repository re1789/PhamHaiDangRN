<?php
$ten = $_POST['ten'];
$namsinh = $_POST['namsinh'];
$sothich = $_POST['sothich'];
$namHienTai = date("Y");
$tuoi = $namHienTai - $namsinh;
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thông tin</title>

    <style>
        body {
            font-family: "Times New Roman", serif;
            font-size: 28px;
        }

        .thongtin {
            width: 490px;
            margin: 80px auto;
            border: 1px solid black;
            padding: 10px;
        }
    </style>
</head>
    <body>
        <div class="thongtin">
            Xin chào bạn <?php echo $ten; ?><br>
            Năm sinh của bạn là <?php echo $namsinh; ?>.<br>
            Năm nay bạn <?php echo $tuoi; ?> tuổi.<br>
            Sở thích của bạn là <?php echo strtolower($sothich); ?>.
        </div>
    </body>
</html>
