<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thông tin đăng ký CLB PHP cơ bản</title>

    <style>
        body {
            font-family: "Times New Roman", Times, serif;
        }

        h1 {
            text-align: center;
            color: green;
            margin-top: 60px;
        }

        .form-dangky {
            width: 360px;
            margin: 30px auto;
        }

        .dong {
            display: flex;
            margin-bottom: 3px;
        }

        .nhan {
            width: 105px;
        }

        input[type="text"],
        input[type="email"] {
            width: 115px;
            height: 18px;
            padding: 0 3px;
            box-sizing: border-box;
        }

        .nut {
            margin-top: 15px;
            margin-left: 108px;
        }
    </style>
</head>

<body>

    <h1>THÔNG TIN ĐĂNG KÝ CLB PHP CƠ BẢN</h1>

    <form class="form-dangky" method="post" action="xl_dangky.php">
        
        <div class="dong">
            <label class="nhan">Nhập họ</label>
            <input type="text" name="ho">
        </div>

        <div class="dong">
            <label class="nhan">Nhập tên</label>
            <input type="text" name="ten">
        </div>

        <div class="dong">
            <label class="nhan">Email</label>
            <input type="email" name="email">
        </div>

        <div class="nut">
            <input type="submit" name="dangky" value="Đăng ký">
            <input type="reset" value="Làm lại">
        </div>
    </form>
</body>
</html>
