<?php
function tinhTong($A, $B) {
    return $A + $B;
}

$ketQua = "";

if (isset($_GET['btnDo'])) {
    $A = $_GET['A'];
    $B = $_GET['B'];

    $ketQua = tinhTong($A, $B);
}

if (isset($_GET['btnReDo'])) {
    $A = "";
    $B = "";
    $ketQua = "";
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tính tổng 2 số</title>
</head>

<body>
    <form name="f-cal" action="tong.php" method="GET">

        <h1 style="color:#090">TÍNH TỔNG 2 SỐ</h1>

        Nhập số nguyên A:
        <input type="text" name="A" id="A" value="<?php echo isset($_GET['A']) ? $_GET['A'] : ''; ?>"
        >
        <br><br>

        Nhập số nguyên B:
        <input 
            type="text" name="B" id="B" value="<?php echo isset($_GET['B']) ? $_GET['B'] : ''; ?>"
        >
        <br><br>

        <input type="submit" value="Thực hiện" name="btnDo">
        <input type="submit" value="Làm lại" name="btnReDo">

        <br><br>

        <?php
        if ($ketQua !== "") {
            echo "Kết quả: <b>" . $ketQua . "</b>";
        }
        ?>

    </form>
</body>
</html>
