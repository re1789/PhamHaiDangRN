<?php
function kiem_tra_snt($n) {
    static $dem_lan_kiem_tra = 0;
    $dem_lan_kiem_tra++;

    if ($n < 2) return 0;
    for ($i = 2; $i <= sqrt($n); $i++) {
        if ($n % $i == 0) return 0;
    }
    return 1;
}

$kq = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $n = isset($_POST['so_n']) ? (int)$_POST['so_n'] : 0;
    $list_snt = array();
    
    for ($i = 2; $i < $n; $i++) {
        if (kiem_tra_snt($i) == 1) {
            $list_snt[] = $i;
        }
    }
    
    if (!empty($list_snt)) {
        $kq = "Các số nguyên tố nhỏ hơn $n là: " . implode(" ", $list_snt);
    } else {
        $kq = "Không có số nguyên tố nào nhỏ hơn $n";
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Số Nguyên Tố</title>

    <!-- Sờ tai -->
    <style>
        .box { border: 1px solid #0284c7; width: 450px; margin: 0 auto; padding: 15px; text-align: center; }
        h2 { color: #ff18ba; margin-top: 0; }
        .result { color: #1e3a8a; font-weight: bold; margin-top: 15px; font-size: 18px; }
    </style>

</head>
<body>
    <div class="box">
        <h2>SỐ NGUYÊN TỐ</h2>
        <form action="" method="post">
            <p>Nhập số nguyên N <input type="number" name="so_n" value="<?php echo isset($_POST['so_n']) ? $_POST['so_n'] : ''; ?>" required></p>
            <p>
                <input type="submit" name="thuc_hien" value="Thực hiện">
                <input type="button" onclick="location.href=location.pathname" value="Làm lại">
            </p>
        </form>
        <?php if ($kq != ""): ?>
            <div class="result"><?php echo $kq; ?></div>
        <?php endif; ?>
    </div>
</body>
</html>