<?php
$kq = "";
function tong($a, $b) {
    $tong = $a + $b; 
    return $tong;
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['thuc_hien'])) {
        $a = isset($_POST['so_a']) ? (float)$_POST['so_a'] : 0;
        $b = isset($_POST['so_b']) ? (float)$_POST['so_b'] : 0;
        
        global $kq;
        $kq = tong($a, $b);
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tính tổng 2 số</title>

    <!-- Sờ tai -->
    <style>
        table { background: #e0f2fe; border: 1px solid #0284c7; margin: 0 auto; width: 400px; }
        th { background: #0284c7; color: white; padding: 10px; font-size: 18px; }
        td { padding: 8px; }
        .center { text-align: center; }
    </style>

</head>
<body>
    <form action="" method="post">
        <table>
            <tr><th colspan="2">TÍNH TỔNG 2 SỐ</th></tr>
            <tr>
                <td>Nhập số nguyên A</td>
                <td><input type="number" name="so_a" value="<?php echo isset($_POST['so_a']) ? $_POST['so_a'] : ''; ?>" required></td>
            </tr>
            <tr>
                <td>Nhập số nguyên B</td>
                <td><input type="number" name="so_b" value="<?php echo isset($_POST['so_b']) ? $_POST['so_b'] : ''; ?>" required></td>
            </tr>
            <?php if ($kq !== ""): ?>
            <tr>
                <td>Tổng:</td>
                <td><input type="text" readonly value="<?php echo $kq; ?>"></td>
            </tr>
            <?php endif; ?>
            <tr>
                <td colspan="2" class="center">
                    <input type="submit" name="thuc_hien" value="Thực hiện">
                    <input type="button" onclick="location.href=location.pathname" value="Làm lại">
                </td>
            </tr>
        </table>
    </form>
</body>
</html>