<?php
function usc($a, $b) {
    $a = abs($a);
    $b = abs($b);
    while ($b != 0) {
        $r = $a % $b;
        $a = $b;
        $b = $r;
    }
    return $a;
}
function rut_gon_phan_so($tu, $mau, &$tuNew, &$mauNew) {
    if ($mau <= 0) return false;

    $ucln = usc($tu, $mau);
    $tuNew = intdiv($tu, $ucln);
    $mauNew = intdiv($mau, $ucln);

    if ($mauNew < 0) {
        $tuNew = -$tuNew;
        $mauNew = -$mauNew;
    }
    return true;
}

$tu_rg = $mau_rg = "";
$error = "";
if (isset($_POST['tinh'])) {
    $tu = (int)$_POST['tuSo'];
    $mau = (int)$_POST['mauSo'];

    if ($mau <= 0 || !rut_gon_phan_so($tu, $mau, $tu_rg, $mau_rg)) {
        $error = "Mẫu số phải lớn hơn 0.";
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Rút gọn phân số</title>

    <!-- Sờ tai -->
    <style>
        .box { border: 1px solid #0284c7; width: 400px; margin: 0 auto; padding: 15px; }
        h3 { color: #ae00ff; text-align: center; margin-top:0; }
        td { padding: 5px; }
    </style>

</head>
<body>
    <div class="box">
        <h3>RÚT GỌN PHÂN SỐ</h3>
        <form action="" method="post">
            <table align="center">
                <tr>
                    <td>Phân số</td>
                    <td>
                        <input type="number" name="tuSo" style="width:50px" value="<?php echo $_POST['tuSo'] ?? ''; ?>" required><br>
                        <hr>
                        <input type="number" name="mauSo" style="width:50px" value="<?php echo $error !== '' ? '' : htmlspecialchars($_POST['mauSo'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
                    </td>
                    <td>Kết quả</td>
                    <td>
                        <input type="text" readonly style="width:50px" value="<?php echo $tu_rg; ?>"><br>
                        <hr>
                        <input type="text" readonly style="width:50px" value="<?php echo $mau_rg; ?>">
                    </td>
                </tr>
                <tr>
                    <td colspan="4" align="center">
                        <br><input type="submit" name="tinh" value="TÍNH">
                    </td>
                </tr>
            </table>
        </form>
        <?php if ($error !== ""): ?>
            <p style="color: red; text-align: center;"><?php echo $error; ?></p>
        <?php endif; ?>
    </div>
</body>
</html>