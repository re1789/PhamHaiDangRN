<?php
function ten($chuoi) {
    $arr = explode(" ", trim($chuoi));
    return end($arr);
}
function ho($chuoi) {
    $arr = explode(" ", trim($chuoi));
    array_pop($arr);
    return implode(" ", $arr);
}

$hoten = $holot = $ten = "";

if (isset($_POST['tinh'])) {
    $hoten = $_POST['hoten'];
    $holot = ho($hoten);
    $ten = ten($hoten);
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tách Họ Tên</title>

    <!-- Sờ tai -->
    <style>
        .box { border: 1px solid #0284c7; width: 450px; margin: 0 auto; padding: 15px; }
        h2 { color: #16a34a; text-align: center; margin-top:0; }
        table { width: 100%; }
        input[type="text"] { width: 90%; }
    </style>
</head>
<body>
    <div class="box">
        <h2>TÁCH HỌ TÊN</h2>
        <form action="" method="post">
            <table>
                <tr>
                    <td>Họ tên</td>
                    <td><input type="text" name="hoten" value="<?php echo $hoten ? $hoten : ''; ?>" required></td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <input type="submit" name="tinh" value="TÁCH">
                    </td>
                </tr>
                <tr>
                    <td>Họ và tên lót</td>
                    <td><input type="text" readonly value="<?php echo $holot; ?>"></td>
                </tr>
                <tr>
                    <td>Tên</td>
                    <td><input type="text" readonly value="<?php echo $ten; ?>"></td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>