<?php
function giaithua($n) {
    static $goiham = 0;
    $goiham++;

    $gt = 1;
    for ($i = 1; $i <= $n; $i++) {
        $gt *= $i;
    }
    return $gt;
}

$kq = "";
if (isset($_POST['start'])) {
    $n = (int)$_POST['soN'];
    if ($n > 1) {
        $kq = giaithua($n);
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tính giai thừa</title>

    <!-- Sờ tai -->
    <style>
        .box { border: 1px solid #0284c7; width: 380px; margin: 0 auto; padding: 15px; text-align: center; }
        h2 { color: #a31697; }
    </style>
    
</head>
<body>
    <div class="box">
        <h2>TÍNH GIAI THỪA</h2>
        <form action="" method="post">
            <p>Nhập N (n > 1): <input type="number" name="soN" min="2" value="<?php echo $_POST['soN'] ?? ''; ?>" required></p>
            <p><input type="submit" name="start" value="Thực hiện"></p>
            <?php if ($kq !== ""): ?>
                <p><strong>Giai thừa của N là: <?php echo $kq; ?></strong></p>
            <?php endif; ?>
        </form>
    </div>
</body>
</html>