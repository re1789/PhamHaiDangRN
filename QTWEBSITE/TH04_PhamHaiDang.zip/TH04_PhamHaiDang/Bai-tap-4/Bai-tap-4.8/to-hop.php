<?php
function giaithua($n) {
    $gt = 1;
    for ($i = 1; $i <= $n; $i++) {
        $gt *= $i;
    }
    return $gt;
}

function to_hop($k, $n) {
    if ($k < 1 || $k > $n) return 0;
    return giaithua($n) / (giaithua($k) * giaithua($n - $k));
}

$kq = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $k = (int)$_POST['soK'];
    $n = (int)$_POST['soN'];
    
    if ($k >= 1 && $k <= $n) {
        $kq = to_hop($k, $n);
    } else {
        $kq = "Điều kiện không thỏa mãn!";
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tính Tổ Hợp</title>

    <!-- Sờ tai -->
    <style>
        .box { border: 1px solid #0284c7; width: 350px; margin: 0 auto; padding: 15px; text-align: center; }
        h2 { color: #9716a3; margin-bottom: 5px; }
        .sub { color: red; font-style: italic; }
    </style>

</head>
<body>
    <div class="box">
        <h2>TÍNH TỔ HỢP C<sup>k</sup><sub>n</sub></h2>
        <form action="" method="post">
            <table align="center">
                <tr>
                    <td>Nhập k</td>
                    <td><input type="number" name="soK" value="<?php echo $_POST['soK'] ?? ''; ?>" required></td>
                </tr>
                <tr>
                    <td>Nhập n</td>
                    <td><input type="number" name="soN" value="<?php echo $_POST['soK'] ?? ''; ?>" required></td>
                </tr>
                <tr>
                    <td colspan="2">
                        <br>
                        <input type="submit" value="Thực hiện">
                        <input type="button" onclick="location.href=location.pathname" value="Làm lại">
                    </td>
                </tr>
            </table>
        </form>
        <?php if ($kq !== ""): ?>
            <p style="color: blue; font-weight: bold;">Kết quả: <?php echo $kq; ?></p>
        <?php endif; ?>
    </div>
</body>
</html>