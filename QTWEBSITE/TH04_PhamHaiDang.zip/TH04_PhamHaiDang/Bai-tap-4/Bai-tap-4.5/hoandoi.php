<?php
function hoan_doi(&$a, &$b) {
    $temp = $a;
    $a = $b;
    $b = $temp;
}

$a_Start = $b_Start = $a_After = $b_After = "";

if (isset($_POST['tinh'])) {
    $a_Start = (int)$_POST['a_Start'];
    $b_Start = (int)$_POST['b_Start'];
    
    $a_After = $a_Start;
    $b_After = $b_Start;
    
    hoan_doi($a_After, $b_After);
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Hoán đổi giá trị</title>

    <!-- Sờ tai -->
    <style>
        .box { border: 1px solid #0284c7; width: 500px; margin: 0 auto; padding: 10px; }
        h3 { color: #a31697; text-align: center; }
    </style>

</head>
<body>
    <div class="box">
        <h3>HOÁN ĐỔI GIÁ TRỊ</h3>
        <form action="" method="post">
            <table align="center" cellpadding="5">
                <tr>
                    <td>Số A ban đầu</td>
                    <td><input type="number" name="a_Start" value="<?php echo $a_Start !== '' ? $a_Start : ''; ?>"></td>
                    <td>Số A lúc sau</td>
                    <td><input type="text" readonly value="<?php echo $a_After; ?>" style="width:60px"></td>
                </tr>
                <tr>
                    <td>Số B ban đầu</td>
                    <td><input type="number" name="b_Start" value="<?php echo $b_Start !== '' ? $b_Start : ''; ?>"></td>
                    <td>Số B lúc sau</td>
                    <td><input type="text" readonly value="<?php echo $b_After; ?>" style="width:60px"></td>
                </tr>
                <tr>
                    <td colspan="4" align="center">
                        <input type="submit" name="tinh" value="TÍNH">
                    </td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>