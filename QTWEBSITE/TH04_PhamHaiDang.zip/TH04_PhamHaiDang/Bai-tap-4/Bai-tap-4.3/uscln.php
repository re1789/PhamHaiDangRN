<?php
function usc($a, $b) {
    $a = abs($a);
    $b = abs($b);
    while ($b != 0) {
        $temp = $b;
        $b = $a % $b;
        $a = $temp;
    }
    return $a;
}

$uscln = null;
if (isset($_POST['tinh'])) {
    $a = (int)$_POST['soA'];
    $b = (int)$_POST['soB'];
    $uscln = ($a === 0 && $b === 0)
        ? 'Không xác định khi A và B đều bằng 0'
        : usc($a, $b);
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Ước số chung lớn nhất</title>

    <!-- Sờ tai -->
    <style>
        .box { border: 1px solid #0284c7; width: 350px; margin: 0 auto; padding: 10px; }
        h3 { color: #ff018d; text-align: center; }
        table { width: 100%; }
    </style>
    
</head>
<body>
    <div class="box">
        <h3>ƯỚC SỐ CHUNG LỚN NHẤT</h3>
        <form action="" method="post">
            <table>
                <tr>
                    <td>Số nguyên A</td>
                    <td><input type="number" name="soA" value="<?php echo $_POST['soA'] ?? ''; ?>" required></td>
                </tr>
                <tr>
                    <td>Số nguyên B</td>
                    <td><input type="number" name="soB" value="<?php echo $_POST['soB'] ?? ''; ?>" required></td>
                </tr>
                <?php if ($uscln !== null): ?>
                <tr>
                    <td>USCLN:</td>
                    <td><input type="text" readonly value="<?php echo $uscln; ?>"></td>
                </tr>
                <?php endif; ?>
                <tr>
                    <td colspan="2" style="text-align: center;">
                        <input type="submit" name="tinh" value="TÍNH">
                        <input type="button" onclick="location.href=location.pathname" value="Làm lại">
                    </td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>