```php
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>In tam giác cân</title>

    <style>
        .container {
            width: 600px;
            margin: 30px auto;
            border: 1px solid #7aa7d9;
            padding: 10px 20px 30px;
        }

        h2 {
            text-align: center;
            color: green;
        }

        .form-row {
            margin: 10px 0;
        }

        label {
            display: inline-block;
            width: 180px;
        }

        input {
            width: 120px;
        }

        .result {
            margin-top: 20px;
            font-family: monospace;
            line-height: 1.2;
            white-space: pre;
        }
    </style>
</head>

<body>

<div class="container">

    <h2>IN TAM GIÁC CÂN</h2>

    <form method="post">
        <div class="form-row">
            <label>Nhập chiều cao</label>
            <input type="number" name="cao" min="1"
                value="<?php echo isset($_POST['cao']) ? $_POST['cao'] : ''; ?>">
        </div>

        <div class="form-row">
            <label>Nhập cạnh đáy</label>
            <input type="number" name="day" min="1"
                value="<?php echo isset($_POST['day']) ? $_POST['day'] : ''; ?>">
        </div>

        <div class="form-row">
            <label></label>
            <button type="submit">Tính</button>
        </div>
    </form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $cao = $_POST["cao"];
    $day = $_POST["day"];

    if ($cao == "" || $day == "") {

        echo "<p style='color:red'>Vui lòng nhập đầy đủ dữ liệu!</p>";

    } elseif ($cao <= 0 || $day <= 0) {

        echo "<p style='color:red'>
                Chiều cao và cạnh đáy phải lớn hơn 0!
              </p>";

    } elseif ($day % 2 == 0) {

        echo "<p style='color:red'>
                Cạnh đáy nên là số lẻ để tạo tam giác cân đẹp!
              </p>";

    } else {

        echo "<div class='result' id='tamGiac'>";

        // Tam giác đặc
        $giua = floor($day / 2);

        for ($i = 0; $i < $cao; $i++) {

            $soSao = 2 * $i + 1;

            if ($soSao > $day) {
                $soSao = $day;
            }

            $khoangTrang = $giua - $i;

            if ($khoangTrang < 0) {
                $khoangTrang = 0;
            }

            echo str_repeat("&nbsp;", $khoangTrang * 2);
            echo str_repeat("* ", $soSao);
            echo "<br>";
        }

        echo "</div>";

        echo "
        <button type='button' id='btnMoRong' onclick='moRong()'>
            Mở rộng
        </button>
        ";

        echo "
        <script>
            let cao = $cao;
            let day = $day;
            let dangRong = false;

            function moRong() {

                let hinh = '';
                let giua = Math.floor(day / 2);

                if (!dangRong) {

                    // Tam giác rỗng
                    for (let i = 0; i < cao; i++) {

                        let soSao = 2 * i + 1;

                        if (soSao > day) {
                            soSao = day;
                        }

                        let khoangTrang = giua - i;

                        if (khoangTrang < 0) {
                            khoangTrang = 0;
                        }

                        hinh += '&nbsp;'.repeat(khoangTrang * 2);

                        for (let j = 0; j < soSao; j++) {

                            if (j == 0 || j == soSao - 1 || i == cao - 1) {
                                hinh += '* ';
                            } else {
                                hinh += '&nbsp;&nbsp;';
                            }
                        }

                        hinh += '<br>';
                    }

                    document.getElementById('tamGiac').innerHTML = hinh;
                    document.getElementById('btnMoRong').innerHTML = 'Thu lại';

                    dangRong = true;

                } else {

                    // Quay lại tam giác đặc
                    for (let i = 0; i < cao; i++) {

                        let soSao = 2 * i + 1;

                        if (soSao > day) {
                            soSao = day;
                        }

                        let khoangTrang = giua - i;

                        if (khoangTrang < 0) {
                            khoangTrang = 0;
                        }

                        hinh += '&nbsp;'.repeat(khoangTrang * 2);
                        hinh += '* '.repeat(soSao);
                        hinh += '<br>';
                    }

                    document.getElementById('tamGiac').innerHTML = hinh;
                    document.getElementById('btnMoRong').innerHTML = 'Mở rộng';

                    dangRong = false;
                }
            }
        </script>
        ";
    }
}
?>

</div>

</body>
</html>
```
