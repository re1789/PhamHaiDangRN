<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tính tổng</title>

    <style>
        .container {
            width: 500px;
            margin: 30px auto;
            border: 1px solid #7aa7d9;
            padding: 20px;
        }

        h2 {
            text-align: center;
            color: green;
        }

        label {
            display: inline-block;
            width: 150px;
        }

        input {
            width: 120px;
        }

        .result {
            margin-top: 20px;
        }
    </style>
</head>

<body>

<div class="container">

    <h2>TÍNH TỔNG</h2>

    <form method="post">

        <p>
            <label>Nhập n:</label>
            <input type="number" name="n" min="0">
        </p>

        <p>
            <label></label>
            <button type="submit">Tính</button>
        </p>

    </form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $n = $_POST["n"];

    if ($n == "") {

        echo "<p style='color:red'>Vui lòng nhập n!</p>";

    } elseif ($n < 0) {

        echo "<p style='color:red'>n phải lớn hơn hoặc bằng 0!</p>";

    } else {

        $s = 0;

        for ($i = 0; $i <= $n; $i++) {

            $tu = pow(-1, $i);
            $mau = 2 * $i + 1;

            $s += $tu / $mau;
        }

        echo "<div class='result'>";
        echo "<b>Kết quả:</b> " . $s . "<br>";
        echo "<b>Xấp xỉ:</b> " . ($s * 4);
        echo "</div>";
    }
}
?>

</div>

</body>
</html>
