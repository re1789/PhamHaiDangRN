<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>In tam giác vuông cân</title>

    <style>
        .container {
            width: 600px;
            margin: 30px auto;
            border: 1px solid #7aa7d9;
            padding: 10px 20px 30px;
        }

        h2 {
            text-align: center;
            color: green;
        }

        .form-row {
            margin: 10px 0;
        }

        label {
            display: inline-block;
            width: 180px;
        }

        input {
            width: 120px;
        }

        .result {
            margin-top: 20px;
            font-family: monospace;
            line-height: 1.2;
            white-space: pre;
        }
    </style>
</head>

<body>

<div class="container">
    <h2>IN TAM GIÁC VUÔNG CÂN</h2>

    <form method="post">
        <div class="form-row">
            <label>Nhập cạnh góc vuông</label>
            <input type="number" name="canh" min="1"
                   value="<?php echo isset($_POST['canh']) ? $_POST['canh'] : ''; ?>">
        </div>

        <div class="form-row">
            <label></label>
            <button type="submit">Tính</button>
        </div>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $canh = $_POST["canh"];

        if ($canh == "") {
            echo "<p style='color:red'>Vui lòng nhập cạnh góc vuông!</p>";
        } elseif ($canh <= 0) {
            echo "<p style='color:red'>Cạnh phải lớn hơn 0!</p>";
        } else {
            echo '<div class="result">';

            for ($i = 1; $i <= $canh; $i++) {
                for ($j = 1; $j <= $i; $j++) {
                    echo "* ";
                }
                echo "<br>";
            }

            echo '</div>';
        }
    }
    ?>
</div>

</body>
</html>