<?php
date_default_timezone_set('Asia/Ho_Chi_Minh');

$ngayTrongtuan = [
    'Chủ nhật',
    'Thứ hai',
    'Thứ ba',
    'Thứ tư',
    'Thứ năm',
    'Thứ sáu',
    'Thứ bảy'
];
$thu = $ngayTrongtuan[(int) date('w')];
$ngay = date('d/m/Y');
echo "Hôm nay là $thu ngày $ngay";
?>