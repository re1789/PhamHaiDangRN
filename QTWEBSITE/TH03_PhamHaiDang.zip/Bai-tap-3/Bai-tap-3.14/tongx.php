<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tính tổng S(n)</title>
</head>
<body>
<h2>Vòng lặp for tính tổng S(n) = x*2 + x*4 + ⋯ + x*2n</h2>
<form method="post">
    Nhập x:
    <input type="number" name="x" required>
    <br><br>
    Nhập n:
    <input type="number" name="n" min="1" required>
    <br><br>
    <input type="submit" value="Tính">
</form>
<?php
if (isset($_POST['x']) && isset($_POST['n'])) {

    $x = (float)$_POST['x'];
    $n = (int)$_POST['n'];
    $tong = 0;
    for ($i = 1; $i <= $n; $i++) {
        $tong = $tong + $x * 2 * $i;
    }
    echo "<p>S($n) = $tong</p>";
}
?>
</body>
</html>