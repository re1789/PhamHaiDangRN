<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Kiểm tra số nguyên tố</title>
</head>
<body>
<h2>KIỂM TRA SỐ NGUYÊN TỐ</h2>
<form method="post">
    Nhập số nguyên n:
    <input type="number" name="n" required>
    <input type="submit" value="Kiểm tra">
</form>
<?php
if (isset($_POST['n'])) {
    $n = (int)$_POST['n'];
    $nguyento = true;
    if ($n < 2) {
        $nguyento = false;
    } else {
        for ($i = 2; $i < $n; $i++) {

            if ($n % $i == 0) {
                $nguyento = false;
                break;
            }
        }
    }
    if ($nguyento) {
        echo "<p>Số $n là số nguyên tố.</p>";
    } else {
        echo "<p>Số $n không phải là số nguyên tố.</p>";
    }
}
?>
</body>
</html>