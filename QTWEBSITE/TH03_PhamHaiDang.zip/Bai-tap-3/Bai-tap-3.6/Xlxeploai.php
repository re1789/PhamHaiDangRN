<?php
$hoTen = trim($_POST['hoTen'] ?? '');
$diemNhap = trim($_POST['diem'] ?? '');
$thongBao = '';
$ketQua = '';
$xepLoai = '';

if ($hoTen === '' || $diemNhap === '') {
    $thongBao = 'Vui lòng nhập đầy đủ họ tên và điểm.';
} elseif (!preg_match('/^[0-9]+(?:[.,][0-9]+)?$/', $diemNhap)) {
    $thongBao = 'Điểm phải là dữ liệu dạng số.';
} else {
    $diem = (float) str_replace(',', '.', $diemNhap);

    if ($diem < 0 || $diem > 10) {
        $thongBao = 'Điểm phải nằm trong khoảng từ 0 đến 10.';
    } else {
        $ketQua = $diem >= 5 ? 'Đạt' : 'Không đạt';

        if ($diem >= 9) {
            $xepLoai = 'Giỏi';
        } elseif ($diem >= 7) {
            $xepLoai = 'Khá';
        } elseif ($diem >= 5) {
            $xepLoai = 'Trung bình';
        } else {
            $xepLoai = 'Yếu';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Kết quả xếp loại</title>
    <style>
        body {
            font-family: "Times New Roman", serif;
            font-size: 18px;
            margin: 20px 40px;
        }

        .loi {
            color: #c00;
            margin: 15px auto;
            width: 425px;
        }

        .ket-qua {
            border: 1px solid #000;
            line-height: 1.5;
            margin: 18px auto;
            padding: 8px;
            width: 425px;
        }

        a {
            display: block;
            margin: 15px auto;
            width: 425px;
        }
    </style>
</head>
<body>
    <?php if ($thongBao !== ''): ?>
        <div class="loi"><?= htmlspecialchars($thongBao, ENT_QUOTES, 'UTF-8') ?></div>
    <?php else: ?>
        <div class="ket-qua">
            Họ tên: <?= htmlspecialchars($hoTen, ENT_QUOTES, 'UTF-8') ?><br>
            Điểm: <?= htmlspecialchars($diemNhap, ENT_QUOTES, 'UTF-8') ?><br>
            Kết quả: <?= $ketQua ?><br>
            Xếp loại: <?= $xepLoai ?>
        </div>
    <?php endif; ?>

    <a href="xeploai.php">Quay lại</a>
</body>
</html>
