<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Form xếp loại</title>
    <style>
        body {
            font-family: "Times New Roman", serif;
            font-size: 18px;
            margin: 20px 40px;
        }

        .khung {
            border: 1px solid #6a9af5;
            margin: 0 auto;
            padding: 12px 20px 16px;
            width: 380px;
        }

        h1 {
            color: #075d0b;
            font-size: 28px;
            margin: 0 0 20px;
            text-align: center;
        }

        .dong {
            margin: 10px 0;
        }

        label {
            display: inline-block;
            width: 110px;
        }

        input {
            box-sizing: border-box;
            font-family: inherit;
            font-size: 16px;
            height: 25px;
            width: 230px;
        }

        button {
            font-family: inherit;
            font-size: 15px;
            margin: 12px 4px 0 114px;
            padding: 2px 10px;
        }
    </style>
</head>
<body>
    <div class="khung">
        <h1>XẾP LOẠI HỌC SINH</h1>
        <form action="Xlxeploai.php" method="post">
            <div class="dong">
                <label for="hoTen">Họ tên</label>
                <input type="text" id="hoTen" name="hoTen" required>
            </div>
            <div class="dong">
                <label for="diem">Điểm</label>
                <input type="text" id="diem" name="diem" required>
            </div>
            <button type="submit">Xếp loại</button>
        </form>
    </div>
</body>
</html>
