<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>In hình chữ nhật</title>

    <style>
        .container {
            width: 600px;
            margin: 30px auto;
            border: 1px solid #7aa7d9;
            padding: 10px 20px 30px;
        }

        h2 {
            text-align: center;
            color: green;
        }

        .form-row {
            margin: 10px 0;
        }

        label {
            display: inline-block;
            width: 180px;
        }

        input {
            width: 120px;
        }

        .result {
            margin-top: 20px;
            font-family: monospace;
            line-height: 1;
            white-space: pre;
        }
    </style>
</head>

<body>

<div class="container">
    <h2>IN HÌNH CHỮ NHẬT</h2>

    <form method="post">
        <div class="form-row">
            <label>Nhập chiều dài</label>
            <input type="number" name="dai" min="1"
                   value="<?php echo isset($_POST['dai']) ? $_POST['dai'] : ''; ?>">
        </div>

        <div class="form-row">
            <label>Nhập chiều rộng</label>
            <input type="number" name="rong" min="1"
                   value="<?php echo isset($_POST['rong']) ? $_POST['rong'] : ''; ?>">
        </div>

        <div class="form-row">
            <label></label>
            <button type="submit">Tính</button>
        </div>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $dai = $_POST["dai"];
        $rong = $_POST["rong"];

        if ($dai == "" || $rong == "") {
            echo "<p style='color:red'>Vui lòng nhập đầy đủ dữ liệu!</p>";
        } elseif ($dai <= 0 || $rong <= 0) {
            echo "<p style='color:red'>Chiều dài và chiều rộng phải lớn hơn 0!</p>";
        } elseif ($rong > $dai) {
            echo "<p style='color:red'>Chiều rộng không được lớn hơn chiều dài!</p>";
        } else {
            echo '<div class="result">';

            for ($i = 1; $i <= $rong; $i++) {
                for ($j = 1; $j <= $dai; $j++) {

                    // Chỉ in dấu * ở đường viền
                    if ($i == 1 || $i == $rong || $j == 1 || $j == $dai) {
                        echo "*";
                    } else {
                        echo " ";
                    }
                }
                echo "<br>";
            }

            echo '</div>';
        }
    }
    ?>
</div>

</body>
</html>