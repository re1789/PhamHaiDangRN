<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tính tổng S(n)</title>
</head>
<body>
<h2>Vòng lặp for tính tổng S(n) = 1 + 1/2 + 1/3 + 1/4 +… 1/n</h2>
<form method="post">
    Nhập n:
    <input type="number" name="n" min="1" required>
    <input type="submit" value="Tính">
</form>
<?php
if (isset($_POST['n'])) {

    $n = (int)$_POST['n'];

    $tong = 0;

    for ($i = 1; $i <= $n; $i++) {
        $tong = $tong + 1 / $i;
    }

    echo "<p>S($n) = $tong</p>";
}
?>
</body>
</html>