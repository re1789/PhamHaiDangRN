<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tính Cos</title>

    <style>
        .container {
            width: 500px;
            margin: 30px auto;
            border: 1px solid #7aa7d9;
            padding: 20px;
        }

        h2 {
            text-align: center;
            color: green;
        }

        label {
            display: inline-block;
            width: 150px;
        }

        input {
            width: 120px;
        }

        .result {
            margin-top: 20px;
        }
    </style>
</head>

<body>

<div class="container">

    <h2>TÍNH COS(X)</h2>

    <form method="post">

        <p>
            <label>Nhập x:</label>
            <input type="number" name="x" step="any">
        </p>

        <p>
            <label>Nhập n:</label>
            <input type="number" name="n" min="0">
        </p>

        <p>
            <label></label>
            <button type="submit">Tính</button>
        </p>

    </form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $x = $_POST["x"];
    $n = $_POST["n"];

    if ($x == "" || $n == "") {

        echo "<p style='color:red'>
                Vui lòng nhập đầy đủ x và n!
              </p>";

    } elseif ($n < 0) {

        echo "<p style='color:red'>n phải lớn hơn hoặc bằng 0!</p>";

    } else {

        $cos = 0;
        for ($i = 0; $i <= $n; $i++) {

            $tu = pow(-1, $i) * pow($x, 2 * $i);

            // Tính giai thừa
            $mau = 1;

            for ($j = 1; $j <= 2 * $i; $j++) {
                $mau *= $j;
            }

            $cos += $tu / $mau;
        }

        echo "<div class='result'>";
        echo "<b>cos($x) ≈ $cos</b>";
        echo "</div>";
    }
}
?>

</div>

</body>
</html>