<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Bình phương</title>
    <style>
        body {
            font-family: "Times New Roman", serif;
            font-size: 18px;
            margin: 20px 40px;
        }

        .khung-nhap {
            border: 1px solid #5c1616;
            max-width: 448px;
            padding: 12px 0 16px;
            text-align: center;
        }

        h1 {
            color: #d8c517;
            font-size: 28px;
            margin: 0 0 24px;
        }

        label {
            color: #075;
            margin-right: 20px;
        }

        input[type="text"] {
            border: 1px solid #8aa9d6;
            font-family: inherit;
            font-size: 16px;
            height: 21px;
            padding: 0 4px;
            width: 145px;
        }

        button {
            font-family: inherit;
            font-size: 14px;
            margin-top: 22px;
            padding: 0px 12px;
            background-color: aqua;
            width: 250px;
        }
    </style>
</head>
<body>
    <div class="khung-nhap">
        <h1>IN BÌNH PHƯƠNG CÁC SỐ</h1>
        <form action="xl_binhphuong.php" method="post">
            <label for="soN">Nhập số nguyên N</label>
            <input type="text" id="soN" name="soN" maxlength="3" required>
            <br>
            <button type="submit">Tính toán</button>
        </form>
    </div>
</body>
</html>
