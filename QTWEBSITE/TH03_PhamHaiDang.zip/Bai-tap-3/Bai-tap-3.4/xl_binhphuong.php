<?php
$soN = trim($_POST['soN'] ?? '');
$thongBao = '';

if (!preg_match('/^[1-9][0-9]{0,2}$/', $soN)) {
    $thongBao = 'Vui lòng nhập số nguyên dương từ 1 đến 999.';
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Bình phương các số</title>
    <style>
        body {
            font-family: "Times New Roman", serif;
            font-size: 18px;
            margin: 20px 40px;
        }

        h1 {
            color: #075d0b;
            font-size: 28px;
            margin: 0 0 24px;
            text-align: center;
        }

        table {
            border-collapse: collapse;
            margin: 0 auto;
            min-width: 470px;
        }

        th,
        td {
            border: 1px solid #555;
            padding: 3px 12px;
            text-align: center;
        }

        th {
            font-size: 20px;
        }

        .loi {
            color: rgb(78, 7, 7);
        }

        a {
            display: block;
            margin-top: 15px;
            text-align: center;
        }
    </style>
</head>
<body>
    <?php if ($thongBao !== ''): ?>
        <div class="loi"><?= htmlspecialchars($thongBao, ENT_QUOTES, 'UTF-8') ?></div>
    <?php else: ?>
        <h1>BÌNH PHƯƠNG CỦA CÁC SỐ TỪ 1 ĐẾN <?= htmlspecialchars($soN, ENT_QUOTES, 'UTF-8') ?> LÀ</h1>
        <table>
            <tr>
                <th>Số i</th>
                <th>Số i<sup>2</sup></th>
            </tr>
            <?php for ($i = 1; $i <= (int) $soN; $i++): ?>
                <tr>
                    <td><?= $i ?></td>
                    <td><?= $i * $i ?></td>
                </tr>
            <?php endfor; ?>
        </table>
    <?php endif; ?>

    <a href="binhphuong.php">Nhập lại</a>
</body>
</html>