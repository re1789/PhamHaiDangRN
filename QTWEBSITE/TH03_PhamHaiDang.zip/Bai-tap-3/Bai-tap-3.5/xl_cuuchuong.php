<?php
$soN = trim($_POST['soN'] ?? '');
$thongBao = '';

if (!preg_match('/^(?:[1-9]|10)$/', $soN)) {
    $thongBao = 'Vui lòng nhập số nguyên dương từ 1 đến 10.';
    // nút quay lại
    echo '<a href="cuuchuong.php">Quay lại</a>';
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Bảng cửu chương</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 16px;
            margin: 20px 40px;
        }

        h1 {
            color: #159447;
            font-size: 22px;
            margin: 0 0 15px;
            text-align: center;
        }

        .ket-qua {
            margin: 0 auto;
            width: 320px;
        }

        table {
            border-collapse: collapse;
            width: 220px;
        }

        td {
            border: 1px solid #555;
            padding: 3px 8px;
        }

        .loi {
            color: rgb(100, 41, 41);
        }

        a {
            display: block;
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <?php if ($thongBao !== ''): ?>
        <div class="loi"><?= htmlspecialchars($thongBao, ENT_QUOTES, 'UTF-8') ?></div>
    <?php else: ?>
        <div class="ket-qua">
            <h1>BẢNG CỬU CHƯƠNG <?= htmlspecialchars($soN, ENT_QUOTES, 'UTF-8') ?></h1>
            <table>
                <?php for ($i = 1; $i <= 10; $i++): ?>
                    <tr>
                        <td><?= $soN ?> x <?= $i ?> = <?= (int) $soN * $i ?></td>
                    </tr>
                <?php endfor; ?>
            </table>
            <button onclick="window.location.href='cuuchuong.php'">Nhập lại</button>
        </div>
    <?php endif; ?>
</body>
</html>
