<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Bảng cửu chương</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 16px;
            margin: 20px 40px;
        }

        .khung-nhap {
            border: 1px solid #6a9af5;
            margin: 0 auto;
            padding: 8px 16px 10px;
            width: 285px;
        }

        h1 {
            color: #159447;
            font-size: 22px;
            margin: 0 0 18px;
            text-align: center;
        }

        .dong-nhap {
            align-items: center;
            display: flex;
            gap: 18px;
        }

        label {
            font-weight: bold;
            white-space: nowrap;
        }

        input {
            box-sizing: border-box;
            font-size: 14px;
            height: 24px;
            width: 115px;
        }

        .ghi-chu {
            font-weight: bold;
            margin-top: 7px;
        }

        button {
            display: block;
            font-size: 14px;
            margin: 10px 0 0 auto;
            padding: 2px 6px;
        }
    </style>
</head>
<body>
    <div class="khung-nhap">
        <h1>BẢNG CỬU CHƯƠNG</h1>
        <form action="xl_cuuchuong.php" method="post">
            <div class="dong-nhap">
                <label for="soN">Nhập số n</label>
                <input type="text" id="soN" name="soN" maxlength="2" required>
            </div>
            <div class="ghi-chu">n là số nguyên dương, có giá trị từ 1 đến 10</div>
            <button type="submit">In Bảng Cửu Chương</button>
        </form>
    </div>
</body>
</html>