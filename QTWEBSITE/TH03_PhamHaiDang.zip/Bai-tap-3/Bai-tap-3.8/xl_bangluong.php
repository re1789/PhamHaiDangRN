<?php

// Nhận dữ liệu từ form luong.php
$hoten = isset($_POST['hoten']) ? $_POST['hoten'] : '';
$ngaycong = isset($_POST['ngaycong']) ? (int)$_POST['ngaycong'] : 0;
$chucvu = isset($_POST['chucvu']) ? $_POST['chucvu'] : '';


// Xác định công nhật và tên chức vụ
switch ($chucvu) {

    case "giamdoc":
        $tenchucvu = "Giám đốc";
        $congnhat = 800000;
        break;

    case "pho_giam_doc":
        $tenchucvu = "Phó giám đốc";
        $congnhat = 700000;
        break;

    case "truong_phong":
        $tenchucvu = "Trưởng phòng";
        $congnhat = 500000;
        break;

    case "nhan_vien":
        $tenchucvu = "Nhân viên";
        $congnhat = 400000;
        break;

    default:
        $tenchucvu = "";
        $congnhat = 0;
}


// Tính lương
$luong = $ngaycong * $congnhat;

// Bảo hiểm xã hội = 10% lương
$baohiem = $luong * 10 / 100;

// Thực lãnh
$thuclanh = $luong - $baohiem;

?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Bảng lương</title>

    <style>
        body {
            font-family: "Times New Roman", serif;
            font-size: 16px;
        }

        .khung {
            width: 440px;
            margin: 20px auto;
            border: 1px solid #4285f4;
            padding: 5px 12px 15px 12px;
        }

        h1 {
            text-align: center;
            color: green;
            font-size: 30px;
            margin: 0 0 25px 0;
        }

        table {
            width: 100%;
        }

        td {
            padding: 3px;
        }

        .ketqua {
            width: 230px;
            height: 18px;
            background-color: #eeeeee;
            border: 1px solid #cccccc;
            padding: 1px 4px;
            color: #666666;
        }
    </style>
</head>

<body>

<div class="khung">

    <h1>BẢNG LƯƠNG</h1>

    <table>

        <tr>
            <td>Họ tên</td>
            <td>
                <div class="ketqua">
                    <?php echo htmlspecialchars($hoten); ?>
                </div>
            </td>
        </tr>

        <tr>
            <td>Chức vụ</td>
            <td>
                <div class="ketqua">
                    <?php echo $tenchucvu; ?>
                </div>
            </td>
        </tr>

        <tr>
            <td>Lương</td>
            <td>
                <div class="ketqua">
                    <?php echo number_format($luong); ?> Đồng
                </div>
            </td>
        </tr>

        <tr>
            <td>Bảo hiểm xã hội</td>
            <td>
                <div class="ketqua">
                    <?php echo number_format($baohiem); ?> Đồng
                </div>
            </td>
        </tr>

        <tr>
            <td>Thực lãnh</td>
            <td>
                <div class="ketqua">
                    <?php echo number_format($thuclanh); ?> Đồng
                </div>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center;">
                <button onclick="window.location.href='luong.php'">Quay lại</button>
            </td>
        </tr>
    </table>
</div>
</body>
</html>