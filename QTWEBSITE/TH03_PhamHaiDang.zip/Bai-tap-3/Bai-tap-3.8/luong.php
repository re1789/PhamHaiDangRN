<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tính tiền lương</title>

    <style>
        body {
            font-family: "Times New Roman", serif;
            font-size: 16px;
        }

        .khung {
            width: 455px;
            margin: 20px auto;
            border: 1px solid #4285f4;
            padding: 5px 12px 15px 12px;
        }

        h1 {
            text-align: center;
            color: green;
            font-size: 30px;
            margin: 0 0 40px 0;
        }

        table {
            width: 100%;
        }

        td {
            padding: 3px;
        }

        .nhap {
            width: 215px;
            height: 18px;
        }

        select {
            width: 220px;
            height: 22px;
        }

        .nut {
            margin-left: 190px;
            padding: 2px 12px;
        }

        .ket-qua {
            margin-top: 10px;
        }
    </style>
</head>

<body>

<div class="khung">

    <h1>TÍNH TIỀN LƯƠNG</h1>
    <form action="xl_bangluong.php" method="post">

        <table>
            <tr>
                <td>Nhập họ tên</td>
                <td>
                    <input
                        type="text"
                        name="hoten"
                        class="nhap"
                        value=""
                    >
                </td>
            </tr>

            <tr>
                <td>Nhập số ngày công</td>
                <td>
                    <input
                        type="number"
                        name="ngaycong"
                        class="nhap"
                        value="0"
                        min="0"
                    >
                </td>
            </tr>

            <tr>
                <td>Chọn chức vụ</td>
                <td>
                    <select name="chucvu">
                        <option value="giamdoc">Giám đốc</option>
                        <option value="pho_giam_doc">Phó giám đốc</option>
                        <option value="truong_phong" selected>
                            Trưởng phòng
                        </option>
                        <option value="nhan_vien">Nhân viên</option>
                    </select>
                </td>
            </tr>

            <tr>
                <td></td>
                <td>
                    <input type="submit" value="Tính" class="nut">
                </td>
            </tr>
        </table>

    </form>

</div>
</body>
</html>