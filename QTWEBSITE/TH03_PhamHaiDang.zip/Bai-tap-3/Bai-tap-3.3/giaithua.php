<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tính giai thừa</title>
    <style>
        body {
            font-family: "Times New Roman", serif;
            font-size: 18px;
            margin: 20px 40px;
        }

        .khung-nhap {
            border: 1px solid #000;
            max-width: 448px;
            padding: 12px 0 16px;
            text-align: center;
        }

        h1 {
            color: #03e;
            font-size: 36px;
            margin: 0 0 18px;
        }

        label {
            color: #075;
            margin-right: 26px;
        }

        input[type="text"] {
            border: 1px solid #8aa9d6;
            font-family: inherit;
            font-size: 16px;
            height: 21px;
            padding: 0 4px;
            width: 145px;
        }

        .nut-bam {
            margin-top: 21px;
        }

        button {
            font-family: inherit;
            font-size: 14px;
            margin: 0 2px;
            padding: 1px 10px;
        }
    </style>
</head>
<body>
    <div class="khung-nhap">
        <h1>TÍNH GIAI THỪA</h1>
        <form action="xl_giaithua.php" method="post">
            <label for="soN">Nhập số nguyên N</label>
            <input type="text" id="soN" name="soN" maxlength="3" required>
            <div class="nut-bam">
                <button type="submit">Tính giai thừa</button>
                <button type="reset">Làm lại</button>
            </div>
        </form>
    </div>
</body>
</html>