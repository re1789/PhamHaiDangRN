<?php
$soN = trim($_POST['soN'] ?? '');
$thongBao = '';
$giaiThua = '';

if (!preg_match('/^[1-9][0-9]{0,2}$/', $soN)) {
    $thongBao = 'Vui lòng nhập số nguyên dương từ 1 đến 999.';
}
else{
    $n = (int) $soN;
    if ($n > 170) {
        $giaiThua = 'INF';
    } else {
        $giaiThua = '1';
        for ($i = 2; $i <= $n; $i++) {
            $giaiThua = nhanSoLon($giaiThua, $i);
        }
    }
}
function nhanSoLon(string $soLon, int $thuaSo): string
{
    $nho = 0;
    $ketQua = '';

    for ($i = strlen($soLon) - 1; $i >= 0; $i--) {
        $tich = ((int) $soLon[$i] * $thuaSo) + $nho;
        $ketQua = ($tich % 10) . $ketQua;
        $nho = intdiv($tich, 10);
    }

    while ($nho > 0) {
        $ketQua = ($nho % 10) . $ketQua;
        $nho = intdiv($nho, 10);
    }

    return $ketQua;
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Xử lý giai thừa</title>
    <style>
        body {
            font-family: "Times New Roman", serif;
            font-size: 18px;
            margin: 20px 40px;
        }

        .ket-qua {
            border: 1px solid #000;
            display: inline-block;
            font-size: 23px;
            font-weight: bold;
            margin-top: 8px;
            padding: 7px 5px;
        }

        .loi {
            color: #c00;
            margin-top: 8px;
        }

        a {
            display: block;
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <div>Kết quả:</div>

    <?php if ($thongBao !== ''): ?>
        <div class="loi"><?= htmlspecialchars($thongBao, ENT_QUOTES, 'UTF-8') ?></div>
    <?php else: ?>
        <div class="ket-qua">
            Số n: <?= htmlspecialchars($soN, ENT_QUOTES, 'UTF-8') ?><br>
            Giai thừa của số <?= htmlspecialchars($soN, ENT_QUOTES, 'UTF-8') ?> là: <?= $giaiThua ?>
        </div>
    <?php endif; ?>

    <a href="giaithua.php">Quay lại</a>
</body>
</html>