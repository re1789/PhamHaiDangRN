<?php
echo "Các số chẵn từ 0 đến 100: ";
for ($i = 0; $i <= 100; $i += 2) {
    echo $i;
    if($i < 100){
        echo ", ";
    }
}
?>