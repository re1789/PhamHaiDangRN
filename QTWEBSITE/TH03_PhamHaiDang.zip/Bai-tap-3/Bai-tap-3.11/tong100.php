<?php
$tong = 0;
for ($i = 1; $i <= 100; $i++) {
    $tong = $tong + $i;
}
echo "Tổng các số từ 1 đến 100 là: " . $tong;
?>