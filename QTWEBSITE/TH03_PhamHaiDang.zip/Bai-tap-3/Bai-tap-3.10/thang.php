<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tính số ngày trong tháng</title>
</head>

<body>

<h2>TÍNH SỐ NGÀY TRONG THÁNG</h2>

<form method="post">
    <label for="thang">Chọn tháng:</label>
    <select name="thang" id="thang" required>
        <option value="">-- Chọn tháng --</option>
        <?php
        for ($i = 1; $i <= 12; $i++) {
            $selected = (isset($_POST['thang']) && $_POST['thang'] == $i) ? 'selected' : '';
            echo "<option value='$i' $selected>Tháng $i</option>";
        }
        ?>
    </select>

    <input type="submit" value="Tính">
</form>

<?php

if (isset($_POST['thang'])) {

    $thang = (int)$_POST['thang'];

    switch ($thang) {

        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            echo "<p>Tháng $thang có 31 ngày.</p>";
            break;

        case 2:
            echo "<p>Tháng 2 có 28 ngày (hoặc 29 ngày năm nhuận).</p>";
            break;

        case 4:
        case 6:
        case 9:
        case 11:
            echo "<p>Tháng $thang có 30 ngày.</p>";
            break;

        default:
            echo "<p>Tháng không hợp lệ!</p>";
    }
}

?>

</body>
</html>