<?php

// Nhận đáp án từ trang tracnghiem.php
$cau1 = isset($_POST['cau1']) ? $_POST['cau1'] : '';
$cau2 = isset($_POST['cau2']) ? $_POST['cau2'] : '';
$cau3 = isset($_POST['cau3']) ? $_POST['cau3'] : '';


// Đáp án đúng
$dapan1 = "3";
$dapan2 = "4";
$dapan3 = "Nam Phi";


// Tính điểm
$diem = 0;

if ($cau1 == $dapan1) {
    $diem++;
}

if ($cau2 == $dapan2) {
    $diem++;
}

if ($cau3 == $dapan3) {
    $diem++;
}


// Nhận xét
if ($diem == 3) {
    $nhanxet = "Đúng hết, giỏi quá!";
} elseif ($diem == 2) {
    $nhanxet = "Tạm được!";
} elseif ($diem == 1) {
    $nhanxet = "Dở quá!";
} else {
    $nhanxet = "Tệ quá! Trời ơi trời!";
}

?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Kết quả</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 13px;
        }

        .ketqua {
            width: 335px;
            margin: 20px auto;
            border: 1px solid #333;
            padding: 8px 18px;
            color: #0000cc;
            font-size: 20px;
            font-weight: bold;
            line-height: 45px;
        }

        .ketqua p {
            margin: 0;
        }

        .ketqua p:before {
            content: "- ";
        }

        .quay-lai {
            text-align: center;
            margin-top: 20px;
        }

        .quay-lai a {
            color: #0000cc;
            text-decoration: none;
        }

        .quay-lai a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>

<div class="ketqua">

    <p>Tổng điểm của bạn là: <?php echo $diem; ?> điểm</p>

    <p><?php echo $nhanxet; ?></p>

</div>

<div class="quay-lai">
    <a href="tracnghiem.php">Làm lại bài trắc nghiệm</a>
</div>

</body>
</html>