<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thi trắc nghiệm</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 13px;
        }

        .khung {
            width: 610px;
            margin: 20px auto;
            border: 1px solid #333;
            padding: 8px 18px 14px 18px;
        }

        h2 {
            text-align: center;
            color: green;
            font-size: 20px;
            margin: 0 0 45px 0;
        }

        .cau {
            display: flex;
            margin-bottom: 15px;
        }

        .so-cau {
            width: 75px;
        }

        .noi-dung {
            line-height: 19px;
        }

        .dap-an {
            margin: 0;
        }

        .nut {
            text-align: center;
            margin-top: 28px;
        }

        input[type="submit"],
        input[type="reset"] {
            padding: 2px 12px;
            margin: 0 2px;
        }
    </style>
</head>

<body>

<div class="khung">

    <h2>CHƯƠNG TRÌNH THI TRẮC NGHIỆM</h2>

    <form action="xl_ketqua.php" method="post">

        <div class="cau">
            <div class="so-cau">Câu 1:</div>

            <div class="noi-dung">
                Thế giới có mấy châu lục?<br>

                <label class="dap-an">
                    <input type="radio" name="cau1" value="3"> 3 châu
                </label><br>

                <label class="dap-an">
                    <input type="radio" name="cau1" value="4"> 4 châu
                </label><br>

                <label class="dap-an">
                    <input type="radio" name="cau1" value="5"> 5 châu
                </label><br>

                <label class="dap-an">
                    <input type="radio" name="cau1" value="6"> 6 châu
                </label>
            </div>
        </div>

        <div class="cau">
            <div class="so-cau">Câu 2:</div>

            <div class="noi-dung">
                Con lừa có mấy chân?<br>

                <label class="dap-an">
                    <input type="radio" name="cau2" value="2"> 2 chân
                </label><br>

                <label class="dap-an">
                    <input type="radio" name="cau2" value="4"> 4 chân
                </label><br>

                <label class="dap-an">
                    <input type="radio" name="cau2" value="5"> 5 chân
                </label><br>

                <label class="dap-an">
                    <input type="radio" name="cau2" value="6"> 6 chân
                </label>
            </div>
        </div>

        <div class="cau">
            <div class="so-cau">Câu 3:</div>

            <div class="noi-dung">
                Worldcup 2010 sẽ diễn ra ở đâu?<br>

                <label class="dap-an">
                    <input type="radio" name="cau3" value="Duc"> Đức
                </label><br>

                <label class="dap-an">
                    <input type="radio" name="cau3" value="Nam Phi"> Nam Phi
                </label><br>

                <label class="dap-an">
                    <input type="radio" name="cau3" value="Anh"> Anh
                </label><br>

                <label class="dap-an">
                    <input type="radio" name="cau3" value="Bo bien nga"> Bờ biển ngà
                </label>
            </div>
        </div>


        <div class="nut">
            <input type="submit" value="Chấm điểm">
            <input type="reset" value="Làm lại">
        </div>

    </form>

</div>

</body>
</html>