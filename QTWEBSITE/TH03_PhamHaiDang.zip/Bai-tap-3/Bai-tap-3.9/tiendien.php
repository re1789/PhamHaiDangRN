<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tính tiền điện</title>

    <style>
        body {
            font-family: "Times New Roman", serif;
            font-size: 14px;
            margin: 0;
        }

        .khung {
            width: 480px;
            margin: 25px auto;
            border: 1px solid #6699ff;
            padding: 5px 10px 15px 10px;
        }

        h1 {
            text-align: center;
            color: green;
            font-size: 28px;
            margin: 0 0 35px 0;
        }

        table {
            width: 100%;
        }

        td {
            padding: 3px;
        }

        input[type="text"] {
            width: 195px;
            height: 18px;
        }

        input[type="number"] {
            width: 195px;
            height: 18px;
        }

        .nut {
           background-color: white;
           border-radius: 5px;
           border: 1px solid;
           padding: 5px;
        }
        .nut:hover {
           background-color: chocolate;
           border: 1px solid;
        }
    </style>
</head>

<body>

<div class="khung">

    <h1>TÍNH TIỀN ĐIỆN</h1>

    <form action="xl_tiendien.php" method="post">

        <table>
            <tr>
                <td>Nhập tên khách hàng</td>
                <td>
                    <input type="text" name="tenkh" value="" required>
                </td>
            </tr>

            <tr>
                <td>Nhập chỉ số đầu tháng</td>
                <td>
                    <input type="number" name="chisodau" value="" required>
                </td>
            </tr>

            <tr>
                <td>Nhập chỉ số cuối tháng</td>
                <td>
                    <input type="number" name="chisocuoi" value="" required>
                </td>
            </tr>

            <tr>
                <td></td>
                <td>
                    <input
                        type="submit" value="Tính tiền điện" class="nut">
                </td>
            </tr>
        </table>
    </form>
</div>
</body>
</html>