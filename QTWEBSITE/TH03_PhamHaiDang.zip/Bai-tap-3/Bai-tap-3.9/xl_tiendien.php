<?php
$tenkh = isset($_POST['tenkh']) ? $_POST['tenkh'] : '';
$chisodau = isset($_POST['chisodau']) ? (int)$_POST['chisodau'] : 0;
$chisocuoi = isset($_POST['chisocuoi']) ? (int)$_POST['chisocuoi'] : 0;

$sokw = $chisocuoi - $chisodau;

if ($sokw < 0) {
    $sokw = 0;
}

$kw1 = 0;
$kw2 = 0;
$kw3 = 0;
$kw4 = 0;

$tien1 = 0;
$tien2 = 0;
$tien3 = 0;
$tien4 = 0;


if ($sokw > 0) {
    $kw1 = min($sokw, 50);
    $tien1 = $kw1 * 3000;
}

if ($sokw > 50) {
    $kw2 = min($sokw - 50, 50);
    $tien2 = $kw2 * 3500;
}

if ($sokw > 100) {
    $kw3 = min($sokw - 100, 50);
    $tien3 = $kw3 * 4000;
}

if ($sokw > 150) {
    $kw4 = $sokw - 150;
    $tien4 = $kw4 * 6000;
}

$tongtien = $tien1 + $tien2 + $tien3 + $tien4;

?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Hóa đơn tiền điện</title>

    <style>
        body {
            font-family: "Times New Roman", serif;
            font-size: 14px;
        }

        .khung {
            width: 385px;
            margin: 25px auto;
            border: 1px solid #6699ff;
            padding: 5px 10px 15px 10px;
        }

        h1 {
            text-align: center;
            color: green;
            font-size: 25px;
            margin: 0 0 30px 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        td {
            padding: 3px;
        }

        .thongtin {
            width: 185px;
            height: 17px;
            background-color: #eeeeee;
            border: 1px solid #cccccc;
            color: #777;
            padding: 1px 4px;
        }

        .bang {
            margin-top: 3px;
        }

        .bang th,
        .bang td {
            border: 1px solid #777;
            padding: 3px;
        }

        .bang th {
            text-align: center;
        }

        .bang td:nth-child(2) {
            text-align: center;
        }

        .bang td:nth-child(3) {
            text-align: left;
        }

        .tong {
            width: 185px;
            height: 17px;
            background-color: #eeeeee;
            border: 1px solid #cccccc;
            color: #777;
            padding: 1px 4px;
        }
        .nut {
           background-color: white;
           border-radius: 5px;
           border: 1px solid;
           padding: 5px;
        }
        .nut:hover {
           background-color: chocolate;
           border: 1px solid;
        }
    </style>
</head>

<body>

<div class="khung">

    <h1>HÓA ĐƠN TIỀN ĐIỆN</h1>

    <table>

        <tr>
            <td>Họ tên khách hàng</td>
            <td>
                <div class="thongtin">
                    <?php echo htmlspecialchars($tenkh); ?>
                </div>
            </td>
        </tr>

        <tr>
            <td>Chỉ số đầu tháng</td>
            <td>
                <div class="thongtin">
                    <?php echo $chisodau; ?>
                </div>
            </td>
        </tr>

        <tr>
            <td>Chỉ số cuối tháng</td>
            <td>
                <div class="thongtin">
                    <?php echo $chisocuoi; ?>
                </div>
            </td>
        </tr>

        <tr>
            <td>Số KW sử dụng</td>
            <td>
                <div class="thongtin">
                    <?php echo $sokw; ?>
                </div>
            </td>
        </tr>

    </table>


    <table class="bang">

        <tr>
            <th></th>
            <th>Số KW</th>
            <th>Thành tiền</th>
        </tr>

        <tr>
            <td>Định mức</td>
            <td><?php echo $kw1; ?></td>
            <td><?php echo number_format($tien1); ?> Đồng</td>
        </tr>

        <tr>
            <td>Vượt mức 1</td>
            <td><?php echo $kw2; ?></td>
            <td><?php echo number_format($tien2); ?> Đồng</td>
        </tr>

        <tr>
            <td>Vượt mức 2</td>
            <td><?php echo $kw3; ?></td>
            <td><?php echo number_format($tien3); ?> Đồng</td>
        </tr>

        <tr>
            <td>Vượt mức 3</td>
            <td><?php echo $kw4; ?></td>
            <td><?php echo number_format($tien4); ?> Đồng</td>
        </tr>

    </table>


    <table>
        <tr>
            <td>Thành tiền</td>
            <td>
                <div class="tong">
                    <?php echo number_format($tongtien); ?> Đồng
                </div>
            </td>
        </tr>
    </table>
    <button onclick="window.history.back();" href="tiendien.php" class="nut">Quay lại</button>
</div>

</body>
</html>